<?php
/**
 * The template for displaying the footer
 *
 */

?>

</div>

<footer class="site-footer"> 
<?php if ( is_active_sidebar( 'sidebar-footer' ) ) { ?>
<div >
<?php dynamic_sidebar( 'sidebar-footer' );  }?>
</div>

</footer>

<?php wp_footer(); ?>

</body>
</html>